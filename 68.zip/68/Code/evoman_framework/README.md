Evoman is a video game playing framework inspired on Megaman.

A demo can be found here:  https://www.youtube.com/watch?v=ZqaMjd1E4ZI
