<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spikes4" tilewidth="32" tileheight="32">
 <image source="evoman/images/spikes4.png" trans="ff00ff" width="94" height="33"/>
</tileset>
